package com.Sprint2.Sprint2_Smart_Soft_Team;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sprint2SmartSoftTeamApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sprint2SmartSoftTeamApplication.class, args);
	}

}
