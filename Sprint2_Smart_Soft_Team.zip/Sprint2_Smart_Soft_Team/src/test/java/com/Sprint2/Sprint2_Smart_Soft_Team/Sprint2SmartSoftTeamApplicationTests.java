package com.Sprint2.Sprint2_Smart_Soft_Team;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sprint2SmartSoftTeamApplicationTests {

	@Test
	void contextLoads() {
	}

}
